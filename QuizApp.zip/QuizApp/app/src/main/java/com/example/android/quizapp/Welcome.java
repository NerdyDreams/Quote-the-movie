package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

public class Welcome extends AppCompatActivity {
    TextView tv;
    // declare variable for radio buttons
    RadioButton answer1;
    RadioButton answer2;
    RadioButton answer3;
    RadioButton answer4;
    RadioButton answer5;
    RadioButton answer6;
    RadioButton answer7;
    RadioButton answer8;
    RadioButton answer9;
    RadioButton answer10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome3);

// display name from user (edittext) on second screen
        tv = findViewById(R.id.your_name);
        tv.setText("Welcome " + getIntent().getStringExtra("NAME") + " ! ");
    }

    //method for the submit action button
    public void submit(View view) {
        CharSequence resultDisplay;
        // Declare Correct answers
        int answer1score;
        int answer2score;
        int answer3score;
        int answer4score;
        int answer5score;
        int answer6score;
        int answer7score;
        int answer8score;
        int answer9score;
        int answer10score;
        int finalScore;

// declare boolean variable for correct answers
        boolean boolAnswer1;
        boolean boolAnswer2;
        boolean boolAnswer3;
        boolean boolAnswer4;
        boolean boolAnswer5;
        boolean boolAnswer6;
        boolean boolAnswer7;
        boolean boolAnswer8;
        boolean boolAnswer9;
        boolean boolAnswer10;


//check if correct answers are picked
        answer1 = this.findViewById(R.id.answer1);
        boolAnswer1 = answer1.isChecked();
        if (boolAnswer1) {
            answer1score = 1;
        } else {
            answer1score = 0;
        }


        answer2 = this.findViewById(R.id.answer2);
        boolAnswer2 = answer2.isChecked();
        if (boolAnswer2) {
            answer2score = 1;
        } else {
            answer2score = 0;
        }

        answer3 = this.findViewById(R.id.answer3);
        boolAnswer3 = answer3.isChecked();
        if (boolAnswer3) {
            answer3score = 1;
        } else {
            answer3score = 0;
        }

        answer4 = this.findViewById(R.id.answer4);
        boolAnswer4 = answer4.isChecked();
        if (boolAnswer4) {
            answer4score = 1;
        } else {
            answer4score = 0;
        }

        answer5 = this.findViewById(R.id.answer5);
        boolAnswer5 = answer5.isChecked();
        if (boolAnswer5) {
            answer5score = 1;
        } else {
            answer5score = 0;
        }

        answer6 = this.findViewById(R.id.answer6);
        boolAnswer6 = answer6.isChecked();
        if (boolAnswer6) {
            answer6score = 1;
        } else {
            answer6score = 0;
        }

        answer7 = this.findViewById(R.id.answer7);
        boolAnswer7 = answer7.isChecked();
        if (boolAnswer7) {
            answer7score = 1;
        } else {
            answer7score = 0;
        }

        answer8 = this.findViewById(R.id.answer8);
        boolAnswer8 = answer8.isChecked();
        if (boolAnswer8) {
            answer8score = 1;
        } else {
            answer8score = 0;
        }

        answer9 = this.findViewById(R.id.answer9);
        boolAnswer9 = answer9.isChecked();
        if (boolAnswer9) {
            answer9score = 1;
        } else {
            answer9score = 0;
        }

        answer10 = this.findViewById(R.id.answer10);
        boolAnswer10 = answer10.isChecked();
        if (boolAnswer10) {
            answer10score = 1;
        } else {
            answer10score = 0;
        }

        // compute a final score for correctly picked answers

        finalScore = answer1score + answer2score + answer3score + answer4score + answer5score + answer6score + answer7score + answer8score + answer9score + answer10score;
        if (finalScore >= 7) {
            resultDisplay = "Score is " + finalScore + " out of 10. Awesome, You're Inspired!!";
        } else {
            resultDisplay = "Score is " + finalScore + " out of 10. Watch more Movies";
        }

        TextView scoreView = findViewById(R.id.summary);
        scoreView.setText(String.valueOf(resultDisplay));

    }
}